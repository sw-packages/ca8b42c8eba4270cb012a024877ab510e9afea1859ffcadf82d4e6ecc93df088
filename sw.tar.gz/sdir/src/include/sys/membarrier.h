#ifndef SYS_MEMBARRIER_H
#define SYS_MEMBARRIER_H

#include "../../../include/sys/membarrier.h"
#include <features.h>

hidden int __membarrier(int, int);

#endif
