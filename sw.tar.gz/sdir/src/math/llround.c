#include <math.h>

long long llround(double x)
{
	return round(x);
}
