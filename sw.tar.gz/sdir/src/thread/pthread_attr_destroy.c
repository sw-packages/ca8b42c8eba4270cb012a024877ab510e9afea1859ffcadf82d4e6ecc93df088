#include "pthread_impl.h"

int pthread_attr_destroy(pthread_attr_t *a)
{
	return 0;
}
