#include "pthread_impl.h"

int pthread_rwlockattr_destroy(pthread_rwlockattr_t *a)
{
	return 0;
}
